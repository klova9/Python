from selenium import webdriver
from selenium.webdriver.firefox.service import Service as FirefoxService
from webdriver_manager.firefox import GeckoDriverManager
from selenium.webdriver.common.by import By
driver = webdriver.Firefox(service=FirefoxService(GeckoDriverManager().install()))
driver.get("https://www.costco.com/CatalogSearch?dept=All&keyword=vinyl+plank+flooring")
containers = driver.find_element(By.ID,"productDescriptionLink_0")    

print(containers)