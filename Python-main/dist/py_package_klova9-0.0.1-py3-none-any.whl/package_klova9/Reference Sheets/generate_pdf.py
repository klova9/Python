
import pdfkit

pdfkit.from_string('template.html', output_path = "craftmy.pdf")