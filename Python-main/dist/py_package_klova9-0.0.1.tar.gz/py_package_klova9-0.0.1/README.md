This is a repository containing most of the code I've made since I started learning python.
My goal is to learn program automation.