import unittest
from src.package_klova9.Practice.Int import array_count9s as count9s
def basic_test():
    testCase = '!99#@9'
    excepted = 3
    #assert(count9s.count9s(testCase, excepted))
    
unittest.main()